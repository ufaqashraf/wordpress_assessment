<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'fnfJ c0p{]GcvVfyU^T?aImRf-K)FzY@<B{/10i-}Q@^ &133J-q XF8H/<gYMFv' );
define( 'SECURE_AUTH_KEY',  'ZA~!h!&##vz#Tu2F_,c)VOkqR75SnurZaLAh&VYYK!h0-oY:{RSs}>`7V~,>zp0x' );
define( 'LOGGED_IN_KEY',    '2x>?f,:#epT[a=Xd 6}bo|YaB4@Yh3ZGtucf)1?QnWp[o~hQRHH`PT,/P&#2#{X2' );
define( 'NONCE_KEY',        '[fl6Vu2-T2o:%]rd?6xD+!Te-xVq/XvSfS4/xX_`W;opTZ0X+37eGOIfFt6r`t/%' );
define( 'AUTH_SALT',        '0b#kGD{VZe$s)m2u:_Nq_Y!,x7[P12]v}f8=U~=2ap!#.ab|n$6oP_xMB)i$,A-+' );
define( 'SECURE_AUTH_SALT', 'ht%/W[o uoCu}R4c8brxj3 Y&T5cL/Mu1)lG7>tkJ:^!p4f#7`w>wvi*JU/DPrtu' );
define( 'LOGGED_IN_SALT',   'zx)q8 lFBCcAi/nQ]1dJXn8YVYv(b9Bal#([g@VEk@b`I;.H./frilXj:E,y!)wH' );
define( 'NONCE_SALT',       ' b-}4/H2u.UgX(tQ$tvW#?S&0.uwKEfa^H7>Ck?.bG5uJU4JXk}eXL-~MW}X6s1Z' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
